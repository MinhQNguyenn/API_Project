package com.example.personalfinance;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PersonalFinanceApplicationTests {

	@Test
	void contextLoads() {
	}

}
